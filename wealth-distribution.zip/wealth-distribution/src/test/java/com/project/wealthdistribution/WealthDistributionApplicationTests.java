package com.project.wealthdistribution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WealthDistributionApplicationTests {

	@Test
	void contextLoads() {
	}

}
