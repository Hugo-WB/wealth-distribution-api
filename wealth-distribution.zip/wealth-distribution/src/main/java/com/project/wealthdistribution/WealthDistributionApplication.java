package com.project.wealthdistribution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WealthDistributionApplication {

	public static void main(String[] args) {
		SpringApplication.run(WealthDistributionApplication.class, args);
	}

}
